/* ui.js — Dark Universe UI Layer
   All DOM manipulation, combat screen rendering,
   Ritual of Chüd mini-game, stat updates
   ============================================== */

const UI = (() => {

  // ── STAT UPDATES ──
  function updateStats() {
    const s = Engine.state;
    const safe = (id, val) => { const el = document.getElementById(id); if (el) el.style.width = val; };
    const txt  = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };

    // Main topbar
    safe('hp-fill',   (s.hp   / s.maxHp)   * 100 + '%');
    safe('san-fill',  (s.sanity / s.maxSanity) * 100 + '%');
    safe('fear-fill', (s.fear / s.maxFear) * 100 + '%');
    txt('hp-val',    s.hp + '/' + s.maxHp);
    txt('san-val',   s.sanity + '/' + s.maxSanity);
    txt('fear-val',  s.fear + '/100');

    // Pulse on danger
    const hpBar  = document.getElementById('hp-bar');
    const sanBar = document.getElementById('san-bar');
    if (hpBar)  hpBar.classList.toggle('pulse-low', s.hp <= 25);
    if (sanBar) sanBar.classList.toggle('pulse-low', s.sanity <= 20);

    // Combat status panel
    const ph = document.getElementById('p-hp-fill');
    const ps = document.getElementById('p-san-fill');
    const pf = document.getElementById('p-fear-fill');
    if (ph) ph.style.width = (s.hp / s.maxHp * 100) + '%';
    if (ps) ps.style.width = (s.sanity / s.maxSanity * 100) + '%';
    if (pf) pf.style.width = (s.fear / s.maxFear * 100) + '%';

    const phRow = document.getElementById('p-hp-row');
    const pfRow = document.getElementById('p-fear-row');
    if (phRow)  phRow.classList.toggle('pulse-danger', s.hp <= 25);
    if (pfRow)  pfRow.classList.toggle('fear-high', s.fear >= 70);

    txt('p-hp-val',   s.hp + '/' + s.maxHp);
    txt('p-san-val',  s.sanity + '/' + s.maxSanity);
    txt('p-fear-val', s.fear);
  }

  function updateMemoryTokens() {
    const s = Engine.state;
    // Topbar tokens
    const wrap = document.getElementById('topbar-memory');
    if (wrap) {
      wrap.innerHTML = '';
      for (let i = 0; i < s.maxTokens; i++) {
        const dot = document.createElement('div');
        dot.className = 'topbar-token' + (i >= s.memoryTokens ? ' spent' : '');
        wrap.appendChild(dot);
      }
    }
    // Combat tokens
    const ct = document.getElementById('memory-tokens');
    if (ct) {
      ct.innerHTML = '';
      for (let i = 0; i < s.maxTokens; i++) {
        const dot = document.createElement('div');
        dot.className = 'mem-token' + (i >= s.memoryTokens ? ' spent' : '');
        wrap.appendChild(dot);
        ct.appendChild(dot.cloneNode());
      }
    }
  }

  function updateInventory() {
    const list = document.getElementById('inventory-list');
    if (!list) return;
    const inv = Engine.state.inventory;
    if (!inv.length) { list.innerHTML = '<div class="inv-empty">Empty pockets...</div>'; return; }
    list.innerHTML = inv.map(i => `
      <div class="inv-item" title="${i.desc || ''}">
        <span class="inv-icon">${i.emoji}</span>
        <div>
          <span class="inv-name">${i.name}</span>
          <span class="inv-effect">${i.effect || ''}</span>
        </div>
      </div>`).join('');
  }

  function updateInventoryScreen() {
    const grid = document.getElementById('inv-grid');
    if (!grid) return;
    const inv = Engine.state.inventory;
    if (!inv.length) { grid.innerHTML = '<div class="inv-empty-full">Your pockets are empty.</div>'; return; }
    grid.innerHTML = inv.map(i => `
      <div class="inv-card">
        <span class="inv-card-icon">${i.emoji}</span>
        <div class="inv-card-name">${i.name}</div>
        <div class="inv-card-desc">${i.desc || ''}</div>
        <div class="inv-card-effect">${i.effect || ''}</div>
      </div>`).join('');
  }

  function updateMap() {
    const mapLayout = window.mapLayout || [];
    const grid = document.getElementById('map-grid');
    if (!grid) return;
    grid.innerHTML = '';
    mapLayout.forEach(node => {
      const cell = document.createElement('div');
      cell.className = 'map-cell';
      cell.innerHTML = node.emoji + `<span class="map-label">${node.label}</span>`;
      if (node.id === Engine.currentNode) cell.classList.add('current');
      if (Engine.hasVisited(node.id)) cell.classList.add('visited');
      if (node.unlock && !Engine.hasVisited(node.unlock)) cell.classList.add('locked');
      if (node.chapter && !Engine.isChapterUnlocked(node.chapter)) cell.classList.add('chapter-locked');
      grid.appendChild(cell);
    });
  }

  // ── STORY ──
  function addStoryBlock(type, text) {
    // On mobile, auto-switch to story tab
    if (window.innerWidth < 700) {
      const t = document.getElementById('tab-story');
      if (t && !t.classList.contains('active')) mobileTab('story');
    }
    const scroll = document.getElementById('story-scroll');
    if (!scroll) return;
    const div = document.createElement('div');
    div.className = 'story-block ' + (type || 'normal');
    div.innerHTML = text;
    scroll.appendChild(div);
    scroll.scrollTop = scroll.scrollHeight;
  }

  function addSeparator() {
    const scroll = document.getElementById('story-scroll');
    if (!scroll) return;
    const sep = document.createElement('div');
    sep.style.cssText = 'height:1px;background:linear-gradient(90deg,transparent,#3a1a10,transparent);margin:14px 0;';
    scroll.appendChild(sep);
  }

  function showChoices(choices) {
    const container = document.getElementById('choices');
    if (!container) return;
    container.innerHTML = '';
    choices.forEach(choice => {
      if (choice.requireItem && !Engine.hasItem(choice.requireItem)) return;
      if (choice.requireFlag && !Engine.getFlag(choice.requireFlag)) return;
      const btn = document.createElement('button');
      btn.className = 'choice-btn ' + (choice.type || 'normal');
      if (choice.memoryReward) btn.classList.add('memory-choice');
      let html = choice.text;
      if (choice.hint) html += `<span class="choice-hint">↳ ${choice.hint}</span>`;
      btn.innerHTML = html;
      btn.onclick = () => Game.handleChoice(choice);
      container.appendChild(btn);
    });
  }

  function clearChoices() {
    const c = document.getElementById('choices');
    if (c) c.innerHTML = '<div style="color:#3a2a20;font-family:\'Share Tech Mono\',monospace;font-size:11px;letter-spacing:2px;">...</div>';
  }

  function addJournal(text) {
    const j = document.getElementById('journal-entries');
    if (j) { j.innerHTML += '— ' + text + '<br>'; j.scrollTop = j.scrollHeight; }
  }

  // ── COMBAT SCREEN ──
  function showCombatScreen(enemy) {
    const screen = document.getElementById('combat-screen');
    if (!screen) return;
    screen.classList.add('active');

    const bg = document.getElementById('scene-bg');
    if (bg) { bg.className = ''; bg.classList.add(enemy.bg || 'sewer'); }

    buildEnemyPortrait(enemy.portrait);
    buildFPSWeaponPanel(enemy);
    spawnSceneParticles(enemy.bg || 'sewer');
    updateEnemyName(enemy.name, enemy.subname, enemy.phaseLabel || '');
    updateEnemyHp(enemy.hp, enemy.maxHp);
    updateStats();
    updateMemoryTokens();

    const log = document.getElementById('combat-log');
    if (log) log.innerHTML = '';
  }

  function hideCombatScreen() {
    const screen = document.getElementById('combat-screen');
    if (screen) screen.classList.remove('active');
    const dial = document.getElementById('combat-dialogue');
    if (dial) dial.classList.remove('active');
    stopPortraitAnimation();
  }

  // ── CANVAS PORTRAIT SYSTEM ──
  let portraitAnimId = null;
  let portraitTime   = 0;
  let currentPortraitType = null;

  function stopPortraitAnimation() {
    if (portraitAnimId) { cancelAnimationFrame(portraitAnimId); portraitAnimId = null; }
  }

  function buildEnemyPortrait(type) {
    stopPortraitAnimation();
    currentPortraitType = type;

    const wrap = document.getElementById('enemy-portrait-wrap');
    if (!wrap) return;
    // Remove old canvas
    const old = document.getElementById('enemy-canvas-el');
    if (old) old.remove();

    const canvas = document.createElement('canvas');
    canvas.id = 'enemy-canvas-el';
    const dpr = window.devicePixelRatio || 1;
    const W = Math.min(340, window.innerWidth * 0.85);
    const H = wrap.clientHeight || 300;
    canvas.width  = W * dpr;
    canvas.height = H * dpr;
    canvas.style.width  = W + 'px';
    canvas.style.height = H + 'px';
    wrap.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    portraitTime = 0;
    function frame(ts) {
      portraitTime = ts * 0.001;
      ctx.clearRect(0, 0, W, H);
      if (type === 'pennywise')      drawPennywise(ctx, W, H, portraitTime);
      else if (type === 'spider')    drawSpider(ctx, W, H, portraitTime);
      else if (type === 'jack')      drawJack(ctx, W, H, portraitTime);
      portraitAnimId = requestAnimationFrame(frame);
    }
    portraitAnimId = requestAnimationFrame(frame);
  }

  // ── PENNYWISE — Canvas drawing, genuinely unsettling ──
  function drawPennywise(ctx, W, H, t) {
    const cx = W / 2;
    // Slow breathing bob
    const bob = Math.sin(t * 1.1) * 5;

    // ── SEWER BACKGROUND ──
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#030808');
    bg.addColorStop(1, '#050302');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // Sewer bricks suggestion
    ctx.strokeStyle = 'rgba(20,10,5,0.6)';
    ctx.lineWidth = 1;
    for (let y = 40; y < H; y += 28) {
      const offset = (Math.floor(y / 28) % 2) * 35;
      for (let x = -35 + offset; x < W + 35; x += 70) {
        ctx.strokeRect(x + 2, y + 2, 66, 24);
      }
    }

    // Sewer water at bottom
    const waterY = H - 60 + Math.sin(t * 0.8) * 3;
    ctx.fillStyle = 'rgba(5,20,5,0.7)';
    ctx.fillRect(0, waterY, W, H - waterY);
    // Ripples
    ctx.strokeStyle = 'rgba(30,60,30,0.4)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.ellipse(cx + Math.sin(t * 0.5 + i * 1.8) * 30, waterY + 10 + i * 12,
        30 + i * 20, 5 + i * 2, 0, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Floating red balloon
    const bx = cx + 55;
    const by = 60 + Math.sin(t * 0.7) * 12 + bob;
    // String
    ctx.strokeStyle = 'rgba(180,20,20,0.5)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(bx, by + 40);
    ctx.quadraticCurveTo(bx + Math.sin(t) * 8, by + 70, bx + 5, by + 110);
    ctx.stroke();
    // Balloon body
    const balloonGrad = ctx.createRadialGradient(bx - 8, by - 10, 3, bx, by, 24);
    balloonGrad.addColorStop(0, '#ff5050');
    balloonGrad.addColorStop(0.6, '#cc0000');
    balloonGrad.addColorStop(1, '#600000');
    ctx.fillStyle = balloonGrad;
    ctx.beginPath();
    ctx.ellipse(bx, by, 20, 26, -0.15, 0, Math.PI * 2);
    ctx.fill();
    // Balloon highlight
    ctx.fillStyle = 'rgba(255,150,150,0.3)';
    ctx.beginPath();
    ctx.ellipse(bx - 7, by - 10, 6, 9, -0.3, 0, Math.PI * 2);
    ctx.fill();

    // ── BODY — white suit ──
    const bodyY = H - 55 + bob * 0.3;
    const bodyW = 100;
    // Body shadow
    const bodyGrad = ctx.createLinearGradient(cx - bodyW/2, H/2, cx + bodyW/2, H/2);
    bodyGrad.addColorStop(0, '#1a1618');
    bodyGrad.addColorStop(0.3, '#e8e4e0');
    bodyGrad.addColorStop(0.7, '#d8d4d0');
    bodyGrad.addColorStop(1, '#1a1618');
    ctx.fillStyle = bodyGrad;
    // Main suit shape
    ctx.beginPath();
    ctx.moveTo(cx - bodyW/2, bodyY);
    ctx.lineTo(cx - bodyW/2 + 10, H);
    ctx.lineTo(cx + bodyW/2 - 10, H);
    ctx.lineTo(cx + bodyW/2, bodyY);
    ctx.quadraticCurveTo(cx, bodyY - 20, cx - bodyW/2, bodyY);
    ctx.fill();

    // Ruffle collar buttons
    ctx.strokeStyle = '#c0bcb8';
    ctx.lineWidth = 2;
    for (let i = -1; i <= 1; i++) {
      ctx.beginPath();
      ctx.arc(cx + i * 20, bodyY + 15, 12, 0, Math.PI * 2);
      ctx.stroke();
    }

    // ── ARMS — reaching, wrong angles ──
    const armSwing = Math.sin(t * 0.9) * 12;
    // Left arm
    ctx.strokeStyle = '#dcdad6';
    ctx.lineWidth = 18;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(cx - 48, bodyY + 20);
    ctx.quadraticCurveTo(cx - 90, bodyY + 60, cx - 75 + armSwing * 0.5, bodyY + 130);
    ctx.stroke();
    // Right arm
    ctx.beginPath();
    ctx.moveTo(cx + 48, bodyY + 20);
    ctx.quadraticCurveTo(cx + 85, bodyY + 55, cx + 72 - armSwing * 0.5, bodyY + 135);
    ctx.stroke();
    // Gloves
    const gloveGrad = (gx, gy) => {
      const g = ctx.createRadialGradient(gx - 4, gy - 4, 2, gx, gy, 18);
      g.addColorStop(0, '#f5f0ec');
      g.addColorStop(1, '#c8c4c0');
      return g;
    };
    ctx.fillStyle = gloveGrad(cx - 75 + armSwing * 0.5, bodyY + 150);
    ctx.beginPath();
    ctx.ellipse(cx - 75 + armSwing * 0.5, bodyY + 150, 18, 14, 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = gloveGrad(cx + 72 - armSwing * 0.5, bodyY + 150);
    ctx.beginPath();
    ctx.ellipse(cx + 72 - armSwing * 0.5, bodyY + 150, 18, 14, -0.2, 0, Math.PI * 2);
    ctx.fill();

    // ── HEAD ──
    const headY = bodyY - 105 + bob;
    const headR = 62;
    // Head shadow/ambient
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath();
    ctx.ellipse(cx + 4, headY + 5, headR, headR * 0.92, 0, 0, Math.PI * 2);
    ctx.fill();
    // Head
    const headGrad = ctx.createRadialGradient(cx - 15, headY - 20, 5, cx, headY, headR);
    headGrad.addColorStop(0, '#f5f0e8');
    headGrad.addColorStop(0.5, '#e8e0d0');
    headGrad.addColorStop(0.85, '#c8c0b0');
    headGrad.addColorStop(1, '#8a8078');
    ctx.fillStyle = headGrad;
    ctx.beginPath();
    ctx.ellipse(cx, headY, headR, headR * 0.92, 0, 0, Math.PI * 2);
    ctx.fill();
    // Pale sickly skin undertone
    ctx.fillStyle = 'rgba(180,200,160,0.06)';
    ctx.beginPath();
    ctx.ellipse(cx, headY, headR * 0.8, headR * 0.7, 0, 0, Math.PI * 2);
    ctx.fill();

    // ── CLOWN HAIR — orange tufts ──
    const hairPositions = [[-headR + 5, -headR * 0.3], [headR - 5, -headR * 0.3], [-headR + 15, -headR * 0.7], [headR - 15, -headR * 0.7]];
    hairPositions.forEach(([hx, hy], i) => {
      const hairGrad = ctx.createRadialGradient(cx + hx - 4, headY + hy - 4, 2, cx + hx, headY + hy, 20);
      hairGrad.addColorStop(0, '#ff7a20');
      hairGrad.addColorStop(0.6, '#e05000');
      hairGrad.addColorStop(1, '#802000');
      ctx.fillStyle = hairGrad;
      ctx.beginPath();
      ctx.ellipse(cx + hx, headY + hy + Math.sin(t * 1.2 + i) * 3, 20, 18, 0, 0, Math.PI * 2);
      ctx.fill();
    });

    // ── EYES — orange, wrong ──
    const eyeBob = Math.sin(t * 1.1) * 3;
    const eyeGlow = 0.6 + Math.sin(t * 2.2) * 0.35;
    [[-24, -8], [24, -8]].forEach(([ex, ey], i) => {
      const eax = cx + ex, eay = headY + ey + eyeBob;
      // Orange glow halo
      ctx.fillStyle = `rgba(255,100,0,${eyeGlow * 0.35})`;
      ctx.beginPath();
      ctx.ellipse(eax, eay, 20, 16, 0, 0, Math.PI * 2);
      ctx.fill();
      // Eye white (stained yellow)
      ctx.fillStyle = '#d8c898';
      ctx.beginPath();
      ctx.ellipse(eax, eay, 13, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      // Iris — deep orange
      const irisGrad = ctx.createRadialGradient(eax - 2, eay - 2, 1, eax, eay, 8);
      irisGrad.addColorStop(0, '#ff9000');
      irisGrad.addColorStop(0.5, '#dd4400');
      irisGrad.addColorStop(1, '#880000');
      ctx.fillStyle = irisGrad;
      ctx.beginPath();
      ctx.ellipse(eax, eay, 8, 9, 0, 0, Math.PI * 2);
      ctx.fill();
      // Pupil — slit
      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.ellipse(eax, eay, 2, 8, 0, 0, Math.PI * 2);
      ctx.fill();
      // Catchlight
      ctx.fillStyle = 'rgba(255,255,220,0.7)';
      ctx.beginPath();
      ctx.ellipse(eax - 3, eay - 3, 3, 2.5, -0.3, 0, Math.PI * 2);
      ctx.fill();
    });

    // ── RED NOSE ──
    const noseGlow = 0.7 + Math.sin(t * 1.8) * 0.3;
    ctx.fillStyle = `rgba(255,20,20,${noseGlow * 0.3})`;
    ctx.beginPath(); ctx.arc(cx, headY + 15, 20, 0, Math.PI * 2); ctx.fill();
    const noseGrad = ctx.createRadialGradient(cx - 5, headY + 10, 2, cx, headY + 15, 13);
    noseGrad.addColorStop(0, '#ff6060');
    noseGrad.addColorStop(0.6, '#ee1111');
    noseGrad.addColorStop(1, '#880000');
    ctx.fillStyle = noseGrad;
    ctx.beginPath(); ctx.arc(cx, headY + 15, 13, 0, Math.PI * 2); ctx.fill();

    // ── MOUTH — wide, wrong number of teeth ──
    const smileOpen = 12 + Math.sin(t * 0.6) * 5;
    // Dark mouth interior
    ctx.fillStyle = '#0a0202';
    ctx.beginPath();
    ctx.ellipse(cx, headY + 38, 38, smileOpen, 0, 0, Math.PI);
    ctx.fill();
    // Teeth — uneven
    const teeth = [-28, -16, -5, 6, 17, 28];
    teeth.forEach((tx, i) => {
      const tw = 9 + (i % 2) * 3;
      const th = 14 + Math.sin(i * 1.3) * 5;
      ctx.fillStyle = i % 3 === 0 ? '#e8e0c8' : '#f5f0e0';
      ctx.beginPath();
      ctx.roundRect(cx + tx - tw/2, headY + 30, tw, th, [0, 0, 4, 4]);
      ctx.fill();
      // Stain
      ctx.fillStyle = 'rgba(180,100,50,0.2)';
      ctx.fillRect(cx + tx - tw/2 + 2, headY + 36, tw - 4, 4);
    });
    // Smile crease lines
    ctx.strokeStyle = 'rgba(80,30,30,0.6)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx - 38, headY + 38);
    ctx.quadraticCurveTo(cx - 55, headY + 50, cx - 45, headY + 60);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx + 38, headY + 38);
    ctx.quadraticCurveTo(cx + 55, headY + 50, cx + 45, headY + 60);
    ctx.stroke();

    // ── DEADLIGHT GLOW — eye-level orange ──
    if (Math.sin(t * 0.3) > 0.7) {
      const dlAlpha = (Math.sin(t * 0.3) - 0.7) * 2.5;
      const dlGrad = ctx.createRadialGradient(cx, headY - 8, 0, cx, headY - 8, 100);
      dlGrad.addColorStop(0, `rgba(255,120,0,${dlAlpha * 0.25})`);
      dlGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = dlGrad;
      ctx.fillRect(0, 0, W, H);
    }

    // ── DRIPPING BLOOD on edges ──
    ctx.fillStyle = 'rgba(100,0,0,0.5)';
    [0.1, 0.25, 0.6, 0.8, 0.95].forEach((xf, i) => {
      const dripX = W * xf;
      const dripH = 15 + Math.sin(t * 0.5 + i) * 10;
      ctx.beginPath();
      ctx.ellipse(dripX, dripH/2, 2, dripH/2, 0, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  // ── IT SPIDER FORM ──
  function drawSpider(ctx, W, H, t) {
    const cx = W / 2;
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#020305');
    bg.addColorStop(1, '#040208');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // Web strands from corners
    ctx.strokeStyle = 'rgba(60,40,80,0.35)';
    ctx.lineWidth = 0.8;
    [[0,0],[W,0],[0,H],[W,H]].forEach(([ox,oy]) => {
      for (let a = 0; a < 5; a++) {
        ctx.beginPath();
        ctx.moveTo(ox, oy);
        ctx.lineTo(cx + Math.cos(a) * 80, H/2 + Math.sin(a) * 60);
        ctx.stroke();
      }
    });

    const bodyY = H * 0.55 + Math.sin(t * 0.8) * 8;

    // ── LEGS — 8 of them, chittering ──
    ctx.strokeStyle = '#150a08';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    for (let i = 0; i < 4; i++) {
      const side = i < 2 ? -1 : 1;
      const legIdx = i % 2;
      const angle1 = (0.3 + legIdx * 0.35) * side;
      const angle2 = (0.8 + legIdx * 0.2) * side;
      const legWave = Math.sin(t * 2.5 + i * 0.7) * 0.12;
      const lx1 = cx + Math.cos(angle1 + legWave) * 55;
      const ly1 = bodyY + Math.sin(angle1 + legWave) * 20;
      const lx2 = cx + Math.cos(angle2 + legWave) * 130;
      const ly2 = bodyY + Math.sin(angle2 + legWave) * 60 + 20;
      ctx.beginPath();
      ctx.moveTo(cx + side * 40, bodyY);
      ctx.quadraticCurveTo(lx1, ly1, lx2, ly2);
      ctx.stroke();
      // Claw tips
      ctx.strokeStyle = '#2a1508';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(lx2, ly2);
      ctx.lineTo(lx2 + side * 10, ly2 + 8);
      ctx.stroke();
      ctx.strokeStyle = '#150a08';
      ctx.lineWidth = 6;
    }

    // Body
    const bodyGrad = ctx.createRadialGradient(cx - 10, bodyY - 15, 5, cx, bodyY, 55);
    bodyGrad.addColorStop(0, '#3a1808');
    bodyGrad.addColorStop(0.7, '#150808');
    bodyGrad.addColorStop(1, '#050202');
    ctx.fillStyle = bodyGrad;
    ctx.beginPath();
    ctx.ellipse(cx, bodyY, 60, 50, 0, 0, Math.PI * 2);
    ctx.fill();

    // Clown face — small, wrong, in center of spider body
    const fx = cx, fy = bodyY - 5 + Math.sin(t * 1.1) * 4;
    ctx.fillStyle = '#d0c8b8';
    ctx.beginPath(); ctx.ellipse(fx, fy, 28, 26, 0, 0, Math.PI * 2); ctx.fill();
    // Orange eyes
    [[-10, -6],[10,-6]].forEach(([ex,ey]) => {
      ctx.fillStyle = '#ff6600';
      ctx.beginPath(); ctx.ellipse(fx+ex, fy+ey, 7, 7, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#000';
      ctx.beginPath(); ctx.ellipse(fx+ex, fy+ey, 3, 5, 0, 0, Math.PI * 2); ctx.fill();
    });
    // Mouth
    ctx.fillStyle = '#300';
    ctx.beginPath(); ctx.ellipse(fx, fy+12, 16, 8, 0, 0, Math.PI); ctx.fill();
    // Deadlight glow pulsing
    const glowPulse = 0.15 + Math.abs(Math.sin(t * 1.3)) * 0.25;
    const spiderGlow = ctx.createRadialGradient(cx, bodyY, 0, cx, bodyY, 120);
    spiderGlow.addColorStop(0, `rgba(120,0,180,${glowPulse})`);
    spiderGlow.addColorStop(1, 'transparent');
    ctx.fillStyle = spiderGlow;
    ctx.fillRect(0, 0, W, H);
  }

  // ── JACK TORRANCE ──
  function drawJack(ctx, W, H, t) {
    const cx = W / 2;
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#040408');
    bg.addColorStop(1, '#08040a');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // Overlook wallpaper suggestion — geometric
    ctx.strokeStyle = 'rgba(30,20,10,0.5)';
    ctx.lineWidth = 0.5;
    for (let y = 0; y < H; y += 24) {
      for (let x = 0; x < W; x += 24) {
        ctx.strokeRect(x + 2, y + 2, 20, 20);
      }
    }

    const bodyY = H - 40 + Math.sin(t * 0.4) * 3;
    const headTilt = Math.sin(t * 0.5) * 0.12;

    // Body — flannel
    const bodyGrad = ctx.createLinearGradient(cx - 55, 0, cx + 55, 0);
    bodyGrad.addColorStop(0, '#1a0a04');
    bodyGrad.addColorStop(0.3, '#3a1808');
    bodyGrad.addColorStop(0.7, '#301408');
    bodyGrad.addColorStop(1, '#1a0a04');
    ctx.fillStyle = bodyGrad;
    ctx.beginPath();
    ctx.moveTo(cx - 55, bodyY);
    ctx.lineTo(cx - 45, H);
    ctx.lineTo(cx + 45, H);
    ctx.lineTo(cx + 55, bodyY);
    ctx.quadraticCurveTo(cx, bodyY - 10, cx - 55, bodyY);
    ctx.fill();

    // Arms — left raises with axe
    const axeAngle = -0.5 + Math.sin(t * 0.6) * 0.25;
    // Right arm (down)
    ctx.strokeStyle = '#2a1208';
    ctx.lineWidth = 22; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(cx + 52, bodyY + 10);
    ctx.quadraticCurveTo(cx + 80, bodyY + 50, cx + 70, bodyY + 100);
    ctx.stroke();
    // Left arm (raised with axe)
    ctx.beginPath();
    ctx.moveTo(cx - 52, bodyY + 10);
    ctx.quadraticCurveTo(cx - 90 + Math.cos(axeAngle) * 20, bodyY - 30 + Math.sin(axeAngle) * 30,
                         cx - 70 + Math.cos(axeAngle) * 50, bodyY - 80 + Math.sin(axeAngle) * 40);
    ctx.stroke();

    // ── AXE ──
    const ax = cx - 70 + Math.cos(axeAngle) * 50;
    const ay = bodyY - 100 + Math.sin(axeAngle) * 40;
    ctx.save();
    ctx.translate(ax, ay);
    ctx.rotate(axeAngle - 0.8);
    // Handle
    ctx.fillStyle = '#4a2808';
    ctx.fillRect(-5, -70, 10, 90);
    // Head
    const axeHeadGrad = ctx.createLinearGradient(-30, -80, 10, -60);
    axeHeadGrad.addColorStop(0, '#888880');
    axeHeadGrad.addColorStop(0.5, '#c8c8c0');
    axeHeadGrad.addColorStop(1, '#606058');
    ctx.fillStyle = axeHeadGrad;
    ctx.beginPath();
    ctx.moveTo(-5, -80);
    ctx.lineTo(-35, -90);
    ctx.lineTo(-40, -60);
    ctx.lineTo(-5, -55);
    ctx.closePath();
    ctx.fill();
    // Blood on blade
    ctx.fillStyle = 'rgba(120,0,0,0.6)';
    ctx.beginPath();
    ctx.moveTo(-5, -72);
    ctx.lineTo(-20, -78);
    ctx.lineTo(-22, -65);
    ctx.lineTo(-5, -62);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // ── HEAD ──
    const headY = bodyY - 110 + Math.sin(t * 0.4) * 4;
    ctx.save(); ctx.translate(cx, headY); ctx.rotate(headTilt);
    // Head shadow
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath(); ctx.ellipse(3, 4, 48, 52, 0, 0, Math.PI * 2); ctx.fill();
    // Face
    const faceGrad = ctx.createRadialGradient(-12, -15, 4, 0, 0, 50);
    faceGrad.addColorStop(0, '#c8a870');
    faceGrad.addColorStop(0.6, '#a08050');
    faceGrad.addColorStop(1, '#604020');
    ctx.fillStyle = faceGrad;
    ctx.beginPath(); ctx.ellipse(0, 0, 46, 52, 0, 0, Math.PI * 2); ctx.fill();
    // 5 o'clock shadow
    ctx.fillStyle = 'rgba(50,30,10,0.2)';
    ctx.beginPath(); ctx.ellipse(0, 15, 30, 22, 0, 0, Math.PI * 2); ctx.fill();

    // Eyes — one slightly wrong, manic
    const blink = Math.sin(t * 0.7) > 0.96 ? 0.1 : 1;
    [[-16, -8], [16, -8]].forEach(([ex, ey], i) => {
      ctx.fillStyle = '#1a0e06';
      ctx.beginPath(); ctx.ellipse(ex, ey, 11, 11 * blink, 0, 0, Math.PI * 2); ctx.fill();
      // Manic shine — both eyes
      ctx.fillStyle = i === 0 ? '#ff8020' : '#ffaa40';
      ctx.beginPath(); ctx.ellipse(ex, ey, 7, 7 * blink, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#000';
      ctx.beginPath(); ctx.ellipse(ex + 1, ey, 4, 4 * blink, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,200,0.8)';
      ctx.beginPath(); ctx.ellipse(ex - 3, ey - 3, 2.5, 2, 0, 0, Math.PI * 2); ctx.fill();
    });

    // Grin — too wide
    ctx.fillStyle = '#0a0402';
    ctx.beginPath();
    ctx.moveTo(-34, 20);
    ctx.quadraticCurveTo(0, 40, 34, 20);
    ctx.quadraticCurveTo(0, 28, -34, 20);
    ctx.fill();
    // Teeth
    for (let ti = -3; ti <= 3; ti++) {
      ctx.fillStyle = ti === 0 ? '#d8c898' : '#e8e0cc';
      ctx.beginPath(); ctx.roundRect(ti * 9 - 4, 20, 8, 14, [0,0,3,3]); ctx.fill();
    }

    // "HEEERE'S JOHNNY" — slight text glow near head when near
    const textAlpha = 0.15 + Math.abs(Math.sin(t * 0.4)) * 0.2;
    ctx.fillStyle = `rgba(255,80,0,${textAlpha})`;
    ctx.font = '10px "Special Elite", serif';
    ctx.textAlign = 'center';
    ctx.fillText('"HEEERE\'S...', 0, -65);
    ctx.restore();
  }

  function updateEnemyPortrait(type) {
    const canvas = document.getElementById('enemy-canvas-el');
    if (canvas) canvas.classList.add('phase-transition');
    setTimeout(() => {
      buildEnemyPortrait(type);
    }, 700);
  }

  function enemyHit() {
    const canvas = document.getElementById('enemy-canvas-el');
    if (!canvas) return;
    canvas.classList.remove('hit');
    void canvas.offsetWidth;
    canvas.classList.add('hit');
    setTimeout(() => canvas.classList.remove('hit'), 350);
  }

  // ── FPS WEAPON PANEL ──
  function buildFPSWeaponPanel(enemy) {
    let panel = document.getElementById('fps-weapon-panel');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'fps-weapon-panel';
      document.getElementById('combat-scene').appendChild(panel);
    }
    const weapon = getActiveWeapon();
    panel.innerHTML = `
      <div id="weapon-left">
        <div id="weapon-name-txt">${weapon.name}</div>
        <div id="weapon-ammo">${weapon.ammo}</div>
      </div>
      <div style="position:relative;">
        <div id="weapon-last-dmg"></div>
        <svg id="weapon-silhouette" viewBox="0 0 90 65" fill="none" xmlns="http://www.w3.org/2000/svg">
          ${weapon.svg}
        </svg>
      </div>`;
  }

  function getActiveWeapon() {
    if (Engine.hasItem("Beverly's Slingshot")) {
      return {
        name: "SILVER SLINGSHOT",
        ammo: "SILVER SLUGS  ◆◆◆◆◆",
        svg: `
          <path d="M55 55 L45 35 L50 20 L55 35 Z" fill="#8a8880" stroke="#555" stroke-width="1"/>
          <path d="M35 55 L45 35 L40 20 L35 35 Z" fill="#8a8880" stroke="#555" stroke-width="1"/>
          <path d="M35 35 Q45 28 55 35" stroke="#aaa" stroke-width="3" fill="none" stroke-linecap="round"/>
          <line x1="35" y1="35" x2="20" y2="15" stroke="#c8b870" stroke-width="1.5" stroke-dasharray="2,3"/>
          <circle cx="20" cy="13" r="4" fill="#d0c060" stroke="#a09040" stroke-width="1"/>
          <path d="M42 55 Q45 58 48 55" stroke="#6a5030" stroke-width="2" fill="none"/>
          <rect x="43" y="55" width="4" height="8" fill="#5a4020" rx="1"/>`
      };
    }
    if (Engine.hasItem('Ritual Knowledge')) {
      return {
        name: "RITUAL OF CHÜD",
        ammo: "WILL POWER  ■■■■■",
        svg: `
          <circle cx="45" cy="30" r="22" stroke="#6a3a8a" stroke-width="2" fill="rgba(60,20,80,0.3)"/>
          <circle cx="45" cy="30" r="14" stroke="#9a60c0" stroke-width="1.5" fill="none" stroke-dasharray="4,2"/>
          <circle cx="45" cy="30" r="6" fill="#c080e0" opacity="0.8"/>
          <line x1="45" y1="8" x2="45" y2="2" stroke="#6a3a8a" stroke-width="1.5"/>
          <line x1="67" y1="30" x2="73" y2="30" stroke="#6a3a8a" stroke-width="1.5"/>
          <line x1="23" y1="30" x2="17" y2="30" stroke="#6a3a8a" stroke-width="1.5"/>
          <line x1="45" y1="52" x2="45" y2="58" stroke="#6a3a8a" stroke-width="1.5"/>
          <text x="45" y="65" text-anchor="middle" fill="#9a60c0" font-size="7" font-family="serif">CHÜD</text>`
      };
    }
    // Default — fists/desperation
    return {
      name: "BARE HANDS",
      ammo: "DESPERATION  ◆◆◆◆◆",
      svg: `
        <path d="M30 60 Q28 40 32 25 Q34 18 38 20 Q42 22 40 30 L42 20 Q44 14 48 16 Q52 18 50 28 L52 22 Q54 16 58 18 Q62 20 60 30 L62 26 Q64 20 68 22 Q72 24 70 35 L68 55 Q65 62 55 63 Q40 64 30 60Z" fill="#c8a870" stroke="#a08050" stroke-width="1.5"/>
        <line x1="40" y1="30" x2="40" y2="55" stroke="#a08050" stroke-width="0.8" opacity="0.5"/>
        <line x1="50" y1="28" x2="50" y2="55" stroke="#a08050" stroke-width="0.8" opacity="0.5"/>
        <line x1="60" y1="30" x2="60" y2="52" stroke="#a08050" stroke-width="0.8" opacity="0.5"/>`
    };
  }

  function showWeaponDamage(dmg, type = 'normal') {
    const el = document.getElementById('weapon-last-dmg');
    if (!el) return;
    const colors = { normal: '#ff4444', silver: '#e8d860', memory: '#f0c840', miss: '#444' };
    el.style.color = colors[type] || colors.normal;
    el.textContent = (dmg > 0 ? '-' + dmg : 'MISS');
    el.classList.remove('pop');
    void el.offsetWidth;
    el.classList.add('pop');
    // Also update weapon name to show what was just used
    const wn = document.getElementById('weapon-name-txt');
    if (wn) {
      const orig = wn.textContent;
      wn.textContent = type === 'silver' ? 'SILVER SHOT' : type === 'memory' ? 'MEMORY SURGE' : type === 'miss' ? '— MISSED —' : orig;
      setTimeout(() => { if (wn) wn.textContent = orig; }, 1200);
    }
  }

  // Spawn scene particles based on location
  function spawnSceneParticles(location) {
    let container = document.getElementById('scene-particles');
    if (!container) {
      container = document.createElement('div');
      container.id = 'scene-particles';
      document.getElementById('combat-scene').appendChild(container);
    }
    container.innerHTML = '';
    const count = location === 'sewer' ? 12 : location === 'overlook' ? 8 : 6;
    const colors = {
      sewer:     ['rgba(20,60,20,0.5)', 'rgba(100,0,0,0.3)', 'rgba(40,80,40,0.4)'],
      derry:     ['rgba(100,0,0,0.3)', 'rgba(60,40,20,0.3)', 'rgba(80,60,40,0.2)'],
      overlook:  ['rgba(20,20,60,0.4)', 'rgba(60,40,80,0.3)', 'rgba(100,80,40,0.2)'],
      darktower: ['rgba(80,0,60,0.4)', 'rgba(40,0,80,0.3)', 'rgba(120,40,0,0.2)']
    };
    const palette = colors[location] || colors.derry;
    for (let i = 0; i < count; i++) {
      const p = document.createElement('div');
      p.className = 'scene-particle';
      p.style.left = Math.random() * 100 + '%';
      p.style.background = palette[Math.floor(Math.random() * palette.length)];
      p.style.width  = (1 + Math.random() * 3) + 'px';
      p.style.height = p.style.width;
      p.style.animationDuration = (4 + Math.random() * 8) + 's';
      p.style.animationDelay    = (-Math.random() * 8) + 's';
      container.appendChild(p);
    }
  }

  function updateEnemyHp(hp, maxHp) {
    const fill = document.getElementById('enemy-hp-fill');
    const nums = document.getElementById('enemy-hp-nums');
    if (fill) fill.style.width = Math.max(0, hp / maxHp * 100) + '%';
    if (nums) nums.textContent = Math.max(0, hp) + ' / ' + maxHp;
  }

  function updateEnemyName(name, subname, phase) {
    const n = document.getElementById('enemy-name-txt');
    const p = document.getElementById('enemy-phase-badge');
    if (n) n.textContent = name + (subname ? ' — ' + subname : '');
    if (p) { p.textContent = phase || ''; p.classList.toggle('show', !!phase); }
  }

  // ── DIALOGUE SYSTEM ──
  function showDialogue(speaker, text, delay = 0) {
    return new Promise(resolve => {
      setTimeout(() => {
        const dial = document.getElementById('combat-dialogue');
        const spk  = document.getElementById('dialogue-speaker');
        const txt  = document.getElementById('dialogue-text');
        if (!dial) { resolve(); return; }

        dial.classList.add('active');
        if (spk) spk.textContent = speaker || '';
        if (txt) txt.innerHTML = '';

        // Typewriter effect
        let i = 0;
        const plain = text.replace(/<[^>]+>/g, '');  // strip tags for typing
        const cursor = document.createElement('span');
        cursor.className = 'dial-cursor';

        const interval = setInterval(() => {
          if (txt) txt.innerHTML = plain.slice(0, i) + (i < plain.length ? '' : '');
          i++;
          if (i > plain.length) {
            clearInterval(interval);
            if (txt) txt.innerHTML = text; // restore full HTML
            setTimeout(resolve, 1800);
          }
        }, 28);
      }, delay);
    });
  }

  // ── COMBAT LOG ──
  function combatLog(type, text) {
    const log = document.getElementById('combat-log');
    if (!log) return;
    const line = document.createElement('div');
    line.className = 'log-line ' + (type || '');
    line.textContent = text;
    log.appendChild(line);
    log.scrollTop = log.scrollHeight;
  }

  // ── COMMAND MENU ──
  function renderCommandMenu(actions) {
    const grid = document.getElementById('command-grid');
    if (!grid) return;
    grid.innerHTML = '';
    actions.forEach(action => {
      const btn = document.createElement('button');
      btn.className = 'cmd-btn';
      if (action.id === 'flee')   btn.classList.add('flee-cmd');
      if (action.id === 'memory') btn.classList.add('memory-cmd');
      if (action.id === 'ritual') btn.classList.add('danger-cmd');
      btn.innerHTML = `
        <span class="cmd-icon">${action.icon}</span>
        <span class="cmd-label">
          ${action.label}
          <span class="cmd-sublabel">${action.sublabel || ''}</span>
        </span>
        ${action.cost === 'token' ? '<span class="cmd-cost">🌟×1</span>' : ''}`;
      btn.onclick = () => Combat.playerAction(action.id);
      grid.appendChild(btn);
    });
  }

  function disableCommands() {
    document.querySelectorAll('.cmd-btn').forEach(b => b.disabled = true);
  }

  function setCombatTurn(isPlayer, isEnemy = false) {
    const txt = document.getElementById('turn-txt');
    const ind = document.getElementById('turn-indicator');
    if (txt) txt.textContent = isPlayer ? 'YOUR TURN' : (isEnemy ? "ITS TURN..." : 'WAIT...');
    if (ind) {
      ind.className = 'turn-indicator';
      if (isEnemy) ind.classList.add('enemy');
    }
  }

  // ── PHASE TRANSITION ──
  function showPhaseTransition(title, sub) {
    return new Promise(resolve => {
      const ov = document.getElementById('phase-overlay');
      const t  = document.getElementById('phase-title');
      const s  = document.getElementById('phase-sub');
      if (!ov) { resolve(); return; }
      if (t) t.textContent = title;
      if (s) s.textContent = sub;
      ov.classList.add('active');
      setTimeout(() => {
        ov.classList.remove('active');
        resolve();
      }, 2500);
    });
  }

  // ── RITUAL OF CHÜD MINI-GAME ──
  function showRitualMinigame(callback) {
    // Build the ritual overlay
    let overlay = document.getElementById('ritual-overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'ritual-overlay';
      overlay.style.cssText = `
        position:fixed;inset:0;z-index:800;
        background:rgba(10,0,20,0.97);
        display:flex;flex-direction:column;align-items:center;justify-content:center;
        gap:20px;padding:30px;
      `;
      document.body.appendChild(overlay);
    }
    overlay.innerHTML = `
      <div style="font-family:'Special Elite',serif;font-size:10px;letter-spacing:5px;color:#6a3a8a;text-transform:uppercase;margin-bottom:10px;">◈ THE RITUAL OF CHÜD</div>
      <div style="font-family:'Crimson Pro',serif;font-style:italic;font-size:16px;color:#c8b0d0;text-align:center;max-width:420px;line-height:1.7;margin-bottom:10px;">
        Bite Its tongue. Hold the clinch. When the bar hits the center — press.<br>
        <span style="font-size:13px;color:#7a5a8a;">The first one to laugh loses everything.</span>
      </div>
      <div id="ritual-track" style="width:min(320px,80vw);height:20px;background:#0a0514;border:1px solid #3a1a5a;border-radius:10px;overflow:hidden;position:relative;">
        <div id="ritual-zone" style="position:absolute;left:40%;width:20%;height:100%;background:rgba(150,80,220,0.3);border-radius:inherit;"></div>
        <div id="ritual-bar" style="width:8px;height:100%;background:linear-gradient(90deg,#8a40cc,#c080ff);border-radius:5px;position:absolute;left:0;transition:none;box-shadow:0 0 10px rgba(180,100,255,0.6);"></div>
      </div>
      <div id="ritual-feedback" style="font-family:'Share Tech Mono',monospace;font-size:11px;color:#4a2a6a;letter-spacing:2px;min-height:20px;"></div>
      <button id="ritual-bite" style="background:transparent;border:2px solid #6a3a8a;color:#9a60c0;padding:14px 40px;font-family:'Special Elite',serif;font-size:1rem;letter-spacing:4px;cursor:pointer;transition:all 0.2s;border-radius:2px;">
        BITE
      </button>
      <div id="ritual-result" style="font-family:'Crimson Pro',serif;font-size:14px;color:#c8b0d0;text-align:center;min-height:20px;display:none;max-width:380px;line-height:1.6;"></div>
    `;
    overlay.style.display = 'flex';

    const bar    = overlay.querySelector('#ritual-bar');
    const btn    = overlay.querySelector('#ritual-bite');
    const fb     = overlay.querySelector('#ritual-feedback');
    const result = overlay.querySelector('#ritual-result');

    let pos = 0;
    let dir = 1;
    let speed = 0.8;
    let animId;
    let done = false;

    function animate() {
      if (done) return;
      pos += dir * speed;
      if (pos >= 92) dir = -1;
      if (pos <= 0)  dir = 1;
      speed = 0.6 + Math.random() * 0.5; // Irregular speed — hard to predict
      bar.style.left = pos + '%';
      animId = requestAnimationFrame(animate);
    }
    animId = requestAnimationFrame(animate);

    btn.onclick = () => {
      if (done) return;
      done = true;
      cancelAnimationFrame(animId);

      // Check timing
      const inZone = pos >= 40 && pos <= 60;
      const nearZone = pos >= 32 && pos <= 68;
      let timing, success;

      if (inZone) {
        timing = 'perfect'; success = true;
        fb.textContent = '★ PERFECT — RIGHT IN THE CENTER';
        fb.style.color = '#f0c040';
        result.textContent = 'You locked It. The laugh-battle goes deep, deeper than the sewers, and you hold.';
      } else if (nearZone) {
        timing = 'good'; success = true;
        fb.textContent = '▸ GOOD — HELD THE CLINCH';
        fb.style.color = '#80c080';
        result.textContent = 'You hold your ground. Not perfectly, but you hold.';
      } else {
        timing = 'poor'; success = Math.random() < 0.35;
        if (success) {
          fb.textContent = '◦ BARELY — Lucky';
          fb.style.color = '#c08040';
          result.textContent = 'By the skin of your teeth. It laughed first — but only just.';
        } else {
          fb.textContent = '✗ TOO SLOW — It laughed first';
          fb.style.color = '#ff4040';
          result.textContent = 'The clinch breaks. The laugh rattles your bones. You lost that round.';
        }
      }

      result.style.display = 'block';
      btn.textContent = 'CONTINUE';
      btn.onclick = () => {
        overlay.style.display = 'none';
        callback(success, timing);
      };
    };
  }

  // ── FX ──
  function showDmgPopup(txt) {
    const p = document.getElementById('dmg-popup');
    if (!p) return;
    p.textContent = txt;
    p.classList.remove('show');
    void p.offsetWidth;
    p.classList.add('show');
  }

  function flashScreen(white = false) {
    const f = document.getElementById('flash-overlay');
    if (!f) return;
    f.className = white ? 'white-flash' : '';
    void f.offsetWidth;
    f.classList.add(white ? 'white-flash' : 'flash');
  }

  function shakeGame() {
    const g = document.getElementById('game-wrap');
    if (!g) return;
    g.classList.add('shake');
    setTimeout(() => g.classList.remove('shake'), 400);
  }

  function fearEffect() {
    const fo = document.getElementById('fear-overlay');
    if (!fo) return;
    fo.classList.remove('active');
    void fo.offsetWidth;
    fo.classList.add('active');
  }

  // ── CHAPTER OVERLAY ──
  function showChapterOverlay() {
    const ov = document.getElementById('chapter-overlay');
    if (!ov) return;
    const grid = document.getElementById('chapter-grid');
    if (!grid) return;
    grid.innerHTML = '';
    Engine.CHAPTER_DEFS.forEach(ch => {
      const unlocked = Engine.isChapterUnlocked(ch.id);
      const complete  = Engine.state.chaptersComplete.includes(ch.id);
      const isCurrent = Engine.state.currentChapter === ch.id;
      const card = document.createElement('div');
      card.className = 'chapter-card' + (!unlocked ? ' locked' : '') + (isCurrent ? ' active-chapter' : '');
      card.innerHTML = `
        <span class="ch-emoji">${ch.emoji}</span>
        <div class="ch-title">${ch.title}</div>
        <div class="ch-sub">${ch.subtitle}<br><span style="font-size:10px;color:#5a4a3a;">${ch.description}</span></div>
        <div class="ch-status ${complete ? 'complete' : ''}">${complete ? '✓ COMPLETE' : (isCurrent ? '▸ CURRENT' : (unlocked ? 'UNLOCKED' : ch.unlockNote))}</div>`;
      if (unlocked) {
        card.onclick = () => {
          Engine.setChapter(ch.id);
          ov.classList.remove('active');
          Game.resetAndStartChapter(ch.id);
        };
      }
      grid.appendChild(card);
    });
    ov.classList.add('active');
  }

  // ── MOBILE TABS ──
  const MOB_PANEL = { map: 0, inv: 1, journal: 2 };

  function mobileTab(tab) {
    ['story','map','inv','journal'].forEach(t => {
      const el = document.getElementById('tab-' + t);
      if (el) el.classList.toggle('active', t === tab);
    });
    if (window.innerWidth >= 700) return;
    const sidePanel   = document.getElementById('side-panel');
    const storyPane   = document.getElementById('story-pane');
    const choicesPane = document.getElementById('choices-pane');
    if (tab === 'story') {
      if (storyPane)   storyPane.style.display  = 'flex';
      if (sidePanel)   sidePanel.style.display  = 'none';
      if (choicesPane) choicesPane.style.display = '';
    } else {
      if (storyPane)   storyPane.style.display   = 'none';
      if (sidePanel)   sidePanel.style.display   = 'flex';
      if (choicesPane) choicesPane.style.display  = 'none';
      const boxes = document.querySelectorAll('#side-panel .panel-box');
      const idx   = MOB_PANEL[tab];
      boxes.forEach((b, i) => b.classList.toggle('mob-active', i === idx));
    }
  }

  window.mobileTab = mobileTab;

  return {
    updateStats, updateMemoryTokens, updateInventory, updateInventoryScreen, updateMap,
    addStoryBlock, addSeparator, showChoices, clearChoices, addJournal,
    showCombatScreen, hideCombatScreen,
    buildEnemyPortrait, updateEnemyPortrait, enemyHit,
    updateEnemyHp, updateEnemyName,
    showDialogue, combatLog,
    renderCommandMenu, disableCommands, setCombatTurn,
    showPhaseTransition, showRitualMinigame,
    showDmgPopup, flashScreen, shakeGame, fearEffect,
    showWeaponDamage, buildFPSWeaponPanel, getActiveWeapon,
    showChapterOverlay, mobileTab
  };

})();
